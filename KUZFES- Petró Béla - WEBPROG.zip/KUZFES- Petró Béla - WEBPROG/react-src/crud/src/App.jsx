import { useEffect, useMemo, useState } from 'react';
import { notebooks as initialNotebooks, processzorok, oprendszerek } from './data';

const formatter = new Intl.NumberFormat('hu-HU');

function NotebookForm({ onSubmit, processzorok, oprendszerek, editingItem, onCancel }) {
  const [form, setForm] = useState(() => ({
    gyarto: editingItem?.gyarto || '',
    tipus: editingItem?.tipus || '',
    kijelzo: editingItem?.kijelzo || '',
    memoria: editingItem?.memoria || '',
    merevlemez: editingItem?.merevlemez || '',
    videovezerlo: editingItem?.videovezerlo || '',
    ar: editingItem?.ar || '',
    processzorid: editingItem?.processzorid || processzorok[0]?.id || '',
    oprendszerid: editingItem?.oprendszerid || oprendszerek[0]?.id || '',
    db: editingItem?.db || 0
  }));

  useEffect(() => {
    setForm({
      gyarto: editingItem?.gyarto || '',
      tipus: editingItem?.tipus || '',
      kijelzo: editingItem?.kijelzo || '',
      memoria: editingItem?.memoria || '',
      merevlemez: editingItem?.merevlemez || '',
      videovezerlo: editingItem?.videovezerlo || '',
      ar: editingItem?.ar || '',
      processzorid: editingItem?.processzorid || processzorok[0]?.id || '',
      oprendszerid: editingItem?.oprendszerid || oprendszerek[0]?.id || '',
      db: editingItem?.db || 0
    });
  }, [editingItem, processzorok, oprendszerek]);

  function handleChange(event) {
    const { name, value } = event.target;
    setForm(prev => ({ ...prev, [name]: value }));
  }

  function submit(event) {
    event.preventDefault();
    onSubmit({
      ...form,
      memoria: Number(form.memoria),
      merevlemez: Number(form.merevlemez),
      ar: Number(form.ar),
      processzorid: Number(form.processzorid),
      oprendszerid: Number(form.oprendszerid),
      db: Number(form.db)
    });
    if (!editingItem) {
      setForm({
        gyarto: '',
        tipus: '',
        kijelzo: '',
        memoria: '',
        merevlemez: '',
        videovezerlo: '',
        ar: '',
        processzorid: processzorok[0]?.id || '',
        oprendszerid: oprendszerek[0]?.id || '',
        db: 0
      });
    }
  }

  return (
    <div className="react-card">
      <h2>{editingItem ? `Notebook szerkesztése (#${editingItem.id})` : 'Új notebook felvitele'}</h2>
      <form onSubmit={submit}>
        <div className="form-grid">
          <input name="gyarto" value={form.gyarto} onChange={handleChange} placeholder="Gyártó" required />
          <input name="tipus" value={form.tipus} onChange={handleChange} placeholder="Típus" required />
          <input name="kijelzo" value={form.kijelzo} onChange={handleChange} placeholder="Kijelző" required />
          <input name="memoria" type="number" min="0" value={form.memoria} onChange={handleChange} placeholder="Memória" required />
          <input name="merevlemez" type="number" min="0" value={form.merevlemez} onChange={handleChange} placeholder="Háttértár" required />
          <input name="videovezerlo" value={form.videovezerlo} onChange={handleChange} placeholder="Videovezérlő" required />
          <input name="ar" type="number" min="0" value={form.ar} onChange={handleChange} placeholder="Ár" required />
          <select name="processzorid" value={form.processzorid} onChange={handleChange}>
            {processzorok.map(item => (
              <option key={item.id} value={item.id}>{item.gyarto} {item.tipus}</option>
            ))}
          </select>
          <select name="oprendszerid" value={form.oprendszerid} onChange={handleChange}>
            {oprendszerek.map(item => (
              <option key={item.id} value={item.id}>{item.nev}</option>
            ))}
          </select>
          <input name="db" type="number" min="0" value={form.db} onChange={handleChange} placeholder="Darabszám" required />
        </div>
        <div className="react-actions" style={{ marginTop: 12 }}>
          <button className="react-btn" type="submit">Mentés</button>
          <button className="react-btn secondary" type="button" onClick={onCancel}>Szerkesztés megszakítása</button>
        </div>
      </form>
    </div>
  );
}

function NotebookTable({ items, onEdit, onDelete }) {
  return (
    <div className="react-card">
      <h2>Notebook lista</h2>
      <div className="react-table-wrap">
        <table className="react-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Gyártó</th>
              <th>Típus</th>
              <th>Ár</th>
              <th>Memória</th>
              <th>Processzor</th>
              <th>Operációs rendszer</th>
              <th>Művelet</th>
            </tr>
          </thead>
          <tbody>
            {items.map(item => (
              <tr key={item.id}>
                <td>{item.id}</td>
                <td>{item.gyarto}</td>
                <td>{item.tipus}</td>
                <td>{formatter.format(item.ar)} Ft</td>
                <td>{formatter.format(item.memoria)} MB</td>
                <td>{item.processzorNev}</td>
                <td>{item.oprendszerNev}</td>
                <td>
                  <div className="react-actions">
                    <button className="react-btn secondary" onClick={() => onEdit(item)}>Szerkesztés</button>
                    <button className="react-btn danger" onClick={() => onDelete(item.id)}>Törlés</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function App() {
  const [notebooks, setNotebooks] = useState(initialNotebooks);
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('ar-asc');
  const [editingItem, setEditingItem] = useState(null);

  const filtered = useMemo(() => {
    const result = notebooks.filter(item => {
      const haystack = `${item.gyarto} ${item.tipus} ${item.videovezerlo}`.toLowerCase();
      return haystack.includes(search.toLowerCase());
    });
    result.sort((a, b) => {
      switch (sort) {
        case 'memoria-desc': return b.memoria - a.memoria;
        case 'gyarto-asc': return a.gyarto.localeCompare(b.gyarto, 'hu');
        default: return a.ar - b.ar;
      }
    });
    return result;
  }, [notebooks, search, sort]);

  function enrich(item, id) {
    const proc = processzorok.find(entry => entry.id === Number(item.processzorid));
    const os = oprendszerek.find(entry => entry.id === Number(item.oprendszerid));
    return {
      ...item,
      id,
      processzorNev: proc ? `${proc.gyarto} ${proc.tipus}` : '',
      oprendszerNev: os ? os.nev : ''
    };
  }

  function saveNotebook(item) {
    if (editingItem) {
      setNotebooks(prev => prev.map(entry => entry.id === editingItem.id ? enrich(item, editingItem.id) : entry));
      setEditingItem(null);
    } else {
      const newId = Math.max(...notebooks.map(item => item.id), 0) + 1;
      setNotebooks(prev => [enrich(item, newId), ...prev]);
    }
  }

  return (
    <div className="react-shell">
      <div className="react-card">
        <h2>React CRUD alkalmazás</h2>
        <div className="controls">
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Keresés gyártó vagy típus alapján..." />
          <select value={sort} onChange={e => setSort(e.target.value)}>
            <option value="ar-asc">Ár növekvő</option>
            <option value="memoria-desc">Memória csökkenő</option>
            <option value="gyarto-asc">Gyártó A-Z</option>
          </select>
          <div className="count-pill">{filtered.length} rekord</div>
        </div>
      </div>

      <NotebookForm
        onSubmit={saveNotebook}
        processzorok={processzorok}
        oprendszerek={oprendszerek}
        editingItem={editingItem}
        onCancel={() => setEditingItem(null)}
      />

      <NotebookTable
        items={filtered}
        onEdit={setEditingItem}
        onDelete={(id) => setNotebooks(prev => prev.filter(item => item.id !== id))}
      />
    </div>
  );
}