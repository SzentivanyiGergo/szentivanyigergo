export const notebooks = [
  {
    "gyarto": "HP",
    "tipus": "COMPAQ 615 NX556EA",
    "kijelzo": "15,6",
    "memoria": 1024,
    "merevlemez": 160,
    "videovezerlo": "ATi Mobility Radeon HD3200 256MB",
    "ar": 95120,
    "processzorid": 1,
    "oprendszerid": 1,
    "db": 0,
    "id": 1,
    "processzorNev": "AMD Athlon 64 X2 QL64",
    "oprendszerNev": "FreeDOS"
  },
  {
    "gyarto": "ASUS",
    "tipus": "K51AC-SX001D",
    "kijelzo": "15,6",
    "memoria": 2048,
    "merevlemez": 250,
    "videovezerlo": "ATi Mobility Radeon HD3200 256MB",
    "ar": 101200,
    "processzorid": 1,
    "oprendszerid": 8,
    "db": 0,
    "id": 2,
    "processzorNev": "AMD Athlon 64 X2 QL64",
    "oprendszerNev": "nincs"
  },
  {
    "gyarto": "HP",
    "tipus": "COMPAQ 615 NX560EA",
    "kijelzo": "15,6",
    "memoria": 2048,
    "merevlemez": 320,
    "videovezerlo": "ATi Mobility Radeon HD3200 256MB",
    "ar": 114800,
    "processzorid": 1,
    "oprendszerid": 4,
    "db": 0,
    "id": 3,
    "processzorNev": "AMD Athlon 64 X2 QL64",
    "oprendszerNev": "Microsoft Vista Home Basic HU"
  },
  {
    "gyarto": "HP",
    "tipus": "Pavilion DV6-1110EH NL956EA",
    "kijelzo": "15,6",
    "memoria": 3072,
    "merevlemez": 250,
    "videovezerlo": "ATi Mobility Radeon HD4530 512MB",
    "ar": 167920,
    "processzorid": 1,
    "oprendszerid": 6,
    "db": 3,
    "id": 4,
    "processzorNev": "AMD Athlon 64 X2 QL64",
    "oprendszerNev": "Microsoft Vista Home Premium HU"
  },
  {
    "gyarto": "ACER",
    "tipus": "Aspire 5536G-642G25MN",
    "kijelzo": "15,6",
    "memoria": 2048,
    "merevlemez": 250,
    "videovezerlo": "ATi Mobility Radeon HD4570 512MB",
    "ar": 111920,
    "processzorid": 1,
    "oprendszerid": 2,
    "db": 3,
    "id": 5,
    "processzorNev": "AMD Athlon 64 X2 QL64",
    "oprendszerNev": "Linux"
  },
  {
    "gyarto": "ACER",
    "tipus": "Aspire 5536G-643G32MN",
    "kijelzo": "15,6",
    "memoria": 3072,
    "merevlemez": 320,
    "videovezerlo": "ATi Mobility Radeon HD4570 512MB",
    "ar": 117520,
    "processzorid": 1,
    "oprendszerid": 2,
    "db": 2,
    "id": 6,
    "processzorNev": "AMD Athlon 64 X2 QL64",
    "oprendszerNev": "Linux"
  },
  {
    "gyarto": "MSI",
    "tipus": "X410-019HU",
    "kijelzo": "14",
    "memoria": 2048,
    "merevlemez": 320,
    "videovezerlo": "ATI Radeon Xpress 1250",
    "ar": 111920,
    "processzorid": 4,
    "oprendszerid": 6,
    "db": 4,
    "id": 7,
    "processzorNev": "AMD Athlon TM Neo MV-40",
    "oprendszerNev": "Microsoft Vista Home Premium HU"
  },
  {
    "gyarto": "ASUS",
    "tipus": "F83T-VX005X",
    "kijelzo": "14",
    "memoria": 4096,
    "merevlemez": 500,
    "videovezerlo": "ATi Mobility Radeon HD4570 512MB",
    "ar": 115920,
    "processzorid": 4,
    "oprendszerid": 8,
    "db": 1,
    "id": 8,
    "processzorNev": "AMD Athlon TM Neo MV-40",
    "oprendszerNev": "nincs"
  },
  {
    "gyarto": "MSI",
    "tipus": "VR630XL-004HU",
    "kijelzo": "16",
    "memoria": 2048,
    "merevlemez": 320,
    "videovezerlo": "NVIDIA GeForce Go 9100M-GS",
    "ar": 90800,
    "processzorid": 5,
    "oprendszerid": 1,
    "db": 1,
    "id": 9,
    "processzorNev": "AMD Mobil Sempron SI-40",
    "oprendszerNev": "FreeDOS"
  },
  {
    "gyarto": "ASUS",
    "tipus": "N60DP-JX012V",
    "kijelzo": "16",
    "memoria": 4096,
    "merevlemez": 500,
    "videovezerlo": "ATi Mobility Radeon HD4670 512MB",
    "ar": 183920,
    "processzorid": 6,
    "oprendszerid": 10,
    "db": 4,
    "id": 10,
    "processzorNev": "AMD Turion64 X2 TL60",
    "oprendszerNev": "Windows 7 Home Premium HU 64Bit"
  },
  {
    "gyarto": "ASUS",
    "tipus": "K50AB-SX045D",
    "kijelzo": "15,6",
    "memoria": 4096,
    "merevlemez": 500,
    "videovezerlo": "ATi Mobility Radeon HD4570 512MB",
    "ar": 134320,
    "processzorid": 7,
    "oprendszerid": 8,
    "db": 5,
    "id": 11,
    "processzorNev": "AMD Turion64 X2 TL64",
    "oprendszerNev": "nincs"
  },
  {
    "gyarto": "FUJITSU",
    "tipus": "Amilo Sa3650",
    "kijelzo": "13,3",
    "memoria": 2048,
    "merevlemez": 250,
    "videovezerlo": "ATi Mobility Radeon HD3200 256MB",
    "ar": 223920,
    "processzorid": 8,
    "oprendszerid": 6,
    "db": 4,
    "id": 12,
    "processzorNev": "AMD Turion64 X2 TL62",
    "oprendszerNev": "Microsoft Vista Home Premium HU"
  },
  {
    "gyarto": "MSI",
    "tipus": "WIND U200-064HU",
    "kijelzo": "12",
    "memoria": 2048,
    "merevlemez": 320,
    "videovezerlo": "Intel Graphics X4500M / 256MB",
    "ar": 112400,
    "processzorid": 51,
    "oprendszerid": 6,
    "db": 3,
    "id": 13,
    "processzorNev": "Intel Celeron M ULV723",
    "oprendszerNev": "Microsoft Vista Home Premium HU"
  },
  {
    "gyarto": "ACER",
    "tipus": "eMachine E525-901G16Mi",
    "kijelzo": "15,6",
    "memoria": 1024,
    "merevlemez": 160,
    "videovezerlo": "Intel Graphics 4500MHD ",
    "ar": 82800,
    "processzorid": 10,
    "oprendszerid": 2,
    "db": 0,
    "id": 14,
    "processzorNev": "Intel Celeron 900",
    "oprendszerNev": "Linux"
  },
  {
    "gyarto": "DELL",
    "tipus": "Inspiron 1545-106208 RED",
    "kijelzo": "15,6",
    "memoria": 1024,
    "merevlemez": 160,
    "videovezerlo": "Intel Graphics 4500MHD ",
    "ar": 103120,
    "processzorid": 10,
    "oprendszerid": 2,
    "db": 3,
    "id": 15,
    "processzorNev": "Intel Celeron 900",
    "oprendszerNev": "Linux"
  },
  {
    "gyarto": "TOSHIBA",
    "tipus": "Satellite L500-1EN",
    "kijelzo": "15,6",
    "memoria": 2048,
    "merevlemez": 320,
    "videovezerlo": "Intel Graphics X4500M / 256MB",
    "ar": 118800,
    "processzorid": 10,
    "oprendszerid": 1,
    "db": 1,
    "id": 16,
    "processzorNev": "Intel Celeron 900",
    "oprendszerNev": "FreeDOS"
  },
  {
    "gyarto": "MSI",
    "tipus": "CR500X-012HU",
    "kijelzo": "15,6",
    "memoria": 2048,
    "merevlemez": 320,
    "videovezerlo": "NVIDIA GeForce Go 8200M 128MB",
    "ar": 94800,
    "processzorid": 10,
    "oprendszerid": 1,
    "db": 1,
    "id": 17,
    "processzorNev": "Intel Celeron 900",
    "oprendszerNev": "FreeDOS"
  },
  {
    "gyarto": "MSI",
    "tipus": "CR500X-008HU",
    "kijelzo": "15,6",
    "memoria": 4096,
    "merevlemez": 320,
    "videovezerlo": "NVIDIA GeForce Go 8200M 128MB",
    "ar": 95920,
    "processzorid": 10,
    "oprendszerid": 1,
    "db": 3,
    "id": 18,
    "processzorNev": "Intel Celeron 900",
    "oprendszerNev": "FreeDOS"
  },
  {
    "gyarto": "LENOVO",
    "tipus": "SL500 2746P5G",
    "kijelzo": "15,4",
    "memoria": 1024,
    "merevlemez": 160,
    "videovezerlo": "NVIDIA GeForce Go 9300M 256MB",
    "ar": 139920,
    "processzorid": 12,
    "oprendszerid": 4,
    "db": 0,
    "id": 19,
    "processzorNev": "Intel Celeron Dual-Core T1600",
    "oprendszerNev": "Microsoft Vista Home Basic HU"
  },
  {
    "gyarto": "TOSHIBA",
    "tipus": "Satellite L300-24P",
    "kijelzo": "15,4",
    "memoria": 2048,
    "merevlemez": 160,
    "videovezerlo": "Intel Graphics 4500MHD",
    "ar": 98000,
    "processzorid": 12,
    "oprendszerid": 1,
    "db": 0,
    "id": 20,
    "processzorNev": "Intel Celeron Dual-Core T1600",
    "oprendszerNev": "FreeDOS"
  },
  {
    "gyarto": "MSI",
    "tipus": "VR603X-094HU",
    "kijelzo": "15,4",
    "memoria": 4096,
    "merevlemez": 320,
    "videovezerlo": "Intel Graphics 4500MHD",
    "ar": 99600,
    "processzorid": 12,
    "oprendszerid": 1,
    "db": 5,
    "id": 21,
    "processzorNev": "Intel Celeron Dual-Core T1600",
    "oprendszerNev": "FreeDOS"
  },
  {
    "gyarto": "HP",
    "tipus": "ProBook 4510s NX435EA",
    "kijelzo": "15,6",
    "memoria": 2048,
    "merevlemez": 250,
    "videovezerlo": "Intel Graphics 4500MHD",
    "ar": 111920,
    "processzorid": 12,
    "oprendszerid": 1,
    "db": 1,
    "id": 22,
    "processzorNev": "Intel Celeron Dual-Core T1600",
    "oprendszerNev": "FreeDOS"
  },
  {
    "gyarto": "FUJITSU",
    "tipus": "Esprimo V6535",
    "kijelzo": "15,4",
    "memoria": 1024,
    "merevlemez": 160,
    "videovezerlo": "Intel Graphics 4500MHD ",
    "ar": 95920,
    "processzorid": 13,
    "oprendszerid": 2,
    "db": 4,
    "id": 23,
    "processzorNev": "Intel Celeron Dual-Core T1700",
    "oprendszerNev": "Linux"
  },
  {
    "gyarto": "LENOVO",
    "tipus": "IdeaPad G550L 59-026377",
    "kijelzo": "15,6",
    "memoria": 1024,
    "merevlemez": 160,
    "videovezerlo": "Intel Graphics 4500MHD",
    "ar": 94320,
    "processzorid": 14,
    "oprendszerid": 4,
    "db": 5,
    "id": 24,
    "processzorNev": "Intel Celeron Dual-Core T3000",
    "oprendszerNev": "Microsoft Vista Home Basic HU"
  },
  {
    "gyarto": "HP",
    "tipus": "Presario CQ61-200SH NZ890EA",
    "kijelzo": "15,6",
    "memoria": 3072,
    "merevlemez": 320,
    "videovezerlo": "Intel Graphics 4500MHD",
    "ar": 127120,
    "processzorid": 14,
    "oprendszerid": 4,
    "db": 3,
    "id": 25,
    "processzorNev": "Intel Celeron Dual-Core T3000",
    "oprendszerNev": "Microsoft Vista Home Basic HU"
  },
  {
    "gyarto": "ACER",
    "tipus": "eMachine E525-302G25Mi",
    "kijelzo": "15,6",
    "memoria": 2048,
    "merevlemez": 250,
    "videovezerlo": "Intel Graphics 4500MHD ",
    "ar": 89200,
    "processzorid": 14,
    "oprendszerid": 2,
    "db": 0,
    "id": 26,
    "processzorNev": "Intel Celeron Dual-Core T3000",
    "oprendszerNev": "Linux"
  },
  {
    "gyarto": "HP",
    "tipus": "ProBook 4510s NX668EA",
    "kijelzo": "15,6",
    "memoria": 2048,
    "merevlemez": 250,
    "videovezerlo": "Intel Graphics 4500MHD ",
    "ar": 113520,
    "processzorid": 14,
    "oprendszerid": 2,
    "db": 3,
    "id": 27,
    "processzorNev": "Intel Celeron Dual-Core T3000",
    "oprendszerNev": "Linux"
  },
  {
    "gyarto": "HP",
    "tipus": "ProBook 4310s NX580EA",
    "kijelzo": "13,3",
    "memoria": 1024,
    "merevlemez": 160,
    "videovezerlo": "Intel Graphics 4500MHD ",
    "ar": 119920,
    "processzorid": 14,
    "oprendszerid": 2,
    "db": 3,
    "id": 28,
    "processzorNev": "Intel Celeron Dual-Core T3000",
    "oprendszerNev": "Linux"
  },
  {
    "gyarto": "ASUS",
    "tipus": "K50IJ-SX036L",
    "kijelzo": "15,6",
    "memoria": 2048,
    "merevlemez": 250,
    "videovezerlo": "Intel Graphics X4500M",
    "ar": 94320,
    "processzorid": 14,
    "oprendszerid": 8,
    "db": 2,
    "id": 29,
    "processzorNev": "Intel Celeron Dual-Core T3000",
    "oprendszerNev": "nincs"
  },
  {
    "gyarto": "ASUS",
    "tipus": "K50IJ-SX153L",
    "kijelzo": "15,6",
    "memoria": 4096,
    "merevlemez": 320,
    "videovezerlo": "Intel Graphics X4500M / 256MB",
    "ar": 100720,
    "processzorid": 14,
    "oprendszerid": 8,
    "db": 0,
    "id": 30,
    "processzorNev": "Intel Celeron Dual-Core T3000",
    "oprendszerNev": "nincs"
  },
  {
    "gyarto": "MSI",
    "tipus": "CR700X-023HU",
    "kijelzo": "17,3",
    "memoria": 3072,
    "merevlemez": 320,
    "videovezerlo": "NVIDIA GeForce Go 8200M 128MB",
    "ar": 108400,
    "processzorid": 14,
    "oprendszerid": 1,
    "db": 0,
    "id": 31,
    "processzorNev": "Intel Celeron Dual-Core T3000",
    "oprendszerNev": "FreeDOS"
  },
  {
    "gyarto": "DELL",
    "tipus": "Vostro V860-111696",
    "kijelzo": "15,6",
    "memoria": 1024,
    "merevlemez": 250,
    "videovezerlo": "Intel Graphics x3100",
    "ar": 79920,
    "processzorid": 17,
    "oprendszerid": 2,
    "db": 3,
    "id": 32,
    "processzorNev": "Intel Celeron M 560",
    "oprendszerNev": "Linux"
  },
  {
    "gyarto": "HP",
    "tipus": "Mini 1199 NS528EA",
    "kijelzo": "10,1",
    "memoria": 1024,
    "merevlemez": 80,
    "videovezerlo": "Intel Graphics 950",
    "ar": 114000,
    "processzorid": 18,
    "oprendszerid": 12,
    "db": 3,
    "id": 33,
    "processzorNev": "Intel Centrino Atom 1600",
    "oprendszerNev": "Windows XP Home Magyar"
  },
  {
    "gyarto": "Asus",
    "tipus": "EEE PC 1001HA-BLK012X BLACK",
    "kijelzo": "10",
    "memoria": 1024,
    "merevlemez": 160,
    "videovezerlo": "Intel Graphics 4500MHD",
    "ar": 59920,
    "processzorid": 19,
    "oprendszerid": 12,
    "db": 4,
    "id": 34,
    "processzorNev": "Intel Centrino Atom N270",
    "oprendszerNev": "Windows XP Home Magyar"
  },
  {
    "gyarto": "Asus",
    "tipus": "EEE PC 1001HA-WHI009X XP WHITE",
    "kijelzo": "10",
    "memoria": 1024,
    "merevlemez": 160,
    "videovezerlo": "Intel Graphics 4500MHD",
    "ar": 59920,
    "processzorid": 19,
    "oprendszerid": 12,
    "db": 4,
    "id": 35,
    "processzorNev": "Intel Centrino Atom N270",
    "oprendszerNev": "Windows XP Home Magyar"
  },
  {
    "gyarto": "DELL",
    "tipus": "Inspiron 1011 104442 BLUE",
    "kijelzo": "10,1",
    "memoria": 1024,
    "merevlemez": 160,
    "videovezerlo": "Intel Graphics 500",
    "ar": 55920,
    "processzorid": 19,
    "oprendszerid": 2,
    "db": 3,
    "id": 36,
    "processzorNev": "Intel Centrino Atom N270",
    "oprendszerNev": "Linux"
  },
  {
    "gyarto": "DELL",
    "tipus": "Inspiron 1011 104437 BLUE",
    "kijelzo": "10,1",
    "memoria": 1024,
    "merevlemez": 160,
    "videovezerlo": "Intel Graphics 500",
    "ar": 63992,
    "processzorid": 19,
    "oprendszerid": 12,
    "db": 1,
    "id": 37,
    "processzorNev": "Intel Centrino Atom N270",
    "oprendszerNev": "Windows XP Home Magyar"
  },
  {
    "gyarto": "DELL",
    "tipus": "Inspiron 1011 104435 BLACK",
    "kijelzo": "10,1",
    "memoria": 1024,
    "merevlemez": 160,
    "videovezerlo": "Intel Graphics 500",
    "ar": 63992,
    "processzorid": 19,
    "oprendszerid": 12,
    "db": 4,
    "id": 38,
    "processzorNev": "Intel Centrino Atom N270",
    "oprendszerNev": "Windows XP Home Magyar"
  },
  {
    "gyarto": "DELL",
    "tipus": "Inspiron 1011 105566 RED",
    "kijelzo": "10,1",
    "memoria": 1024,
    "merevlemez": 160,
    "videovezerlo": "Intel Graphics 500",
    "ar": 63992,
    "processzorid": 19,
    "oprendszerid": 12,
    "db": 1,
    "id": 39,
    "processzorNev": "Intel Centrino Atom N270",
    "oprendszerNev": "Windows XP Home Magyar"
  },
  {
    "gyarto": "DELL",
    "tipus": "Inspiron 1011 104434 WHITE",
    "kijelzo": "10,1",
    "memoria": 1024,
    "merevlemez": 160,
    "videovezerlo": "Intel Graphics 500",
    "ar": 63992,
    "processzorid": 19,
    "oprendszerid": 12,
    "db": 5,
    "id": 40,
    "processzorNev": "Intel Centrino Atom N270",
    "oprendszerNev": "Windows XP Home Magyar"
  }
];
export const processzorok = [
  {
    "id": 1,
    "gyarto": "AMD",
    "tipus": "Athlon 64 X2 QL64"
  },
  {
    "id": 4,
    "gyarto": "AMD",
    "tipus": "Athlon TM Neo MV-40"
  },
  {
    "id": 5,
    "gyarto": "AMD",
    "tipus": "Mobil Sempron SI-40"
  },
  {
    "id": 6,
    "gyarto": "AMD",
    "tipus": "Turion64 X2 TL60"
  },
  {
    "id": 7,
    "gyarto": "AMD",
    "tipus": "Turion64 X2 TL64"
  },
  {
    "id": 8,
    "gyarto": "AMD",
    "tipus": "Turion64 X2 TL62"
  },
  {
    "id": 10,
    "gyarto": "Intel",
    "tipus": "Celeron 900"
  },
  {
    "id": 12,
    "gyarto": "Intel",
    "tipus": "Celeron Dual-Core T1600"
  },
  {
    "id": 13,
    "gyarto": "Intel",
    "tipus": "Celeron Dual-Core T1700"
  },
  {
    "id": 14,
    "gyarto": "Intel",
    "tipus": "Celeron Dual-Core T3000"
  },
  {
    "id": 17,
    "gyarto": "Intel",
    "tipus": "Celeron M 560"
  },
  {
    "id": 18,
    "gyarto": "Intel",
    "tipus": "Centrino Atom 1600"
  },
  {
    "id": 19,
    "gyarto": "Intel",
    "tipus": "Centrino Atom N270"
  },
  {
    "id": 20,
    "gyarto": "Intel",
    "tipus": "Centrino Atom N280"
  },
  {
    "id": 21,
    "gyarto": "Intel",
    "tipus": "Centrino Atom Z520"
  },
  {
    "id": 22,
    "gyarto": "Intel",
    "tipus": "Centrino Atom Z530"
  },
  {
    "id": 23,
    "gyarto": "Intel",
    "tipus": "Core Duo T3400"
  },
  {
    "id": 24,
    "gyarto": "Intel",
    "tipus": "Core2 Duo P7350"
  },
  {
    "id": 25,
    "gyarto": "Intel",
    "tipus": "Core2 Duo P8400"
  },
  {
    "id": 26,
    "gyarto": "Intel",
    "tipus": "Core2 Duo P8600"
  },
  {
    "id": 27,
    "gyarto": "Intel",
    "tipus": "Core2 Duo P8700"
  },
  {
    "id": 28,
    "gyarto": "Intel",
    "tipus": "Core2 Duo SL9400"
  },
  {
    "id": 29,
    "gyarto": "Intel",
    "tipus": "Core2 Duo SU7300"
  },
  {
    "id": 30,
    "gyarto": "Intel",
    "tipus": "Core2 Duo SU9300"
  },
  {
    "id": 31,
    "gyarto": "Intel",
    "tipus": "Core2 Duo SU9400"
  },
  {
    "id": 32,
    "gyarto": "Intel",
    "tipus": "Core2 Duo T5670"
  },
  {
    "id": 34,
    "gyarto": "Intel",
    "tipus": "Core2 Duo T5870"
  },
  {
    "id": 35,
    "gyarto": "Intel",
    "tipus": "Core2 Duo T6400"
  },
  {
    "id": 36,
    "gyarto": "Intel",
    "tipus": "Core2 Duo T6500"
  },
  {
    "id": 37,
    "gyarto": "Intel",
    "tipus": "Core2 Duo T6570"
  },
  {
    "id": 38,
    "gyarto": "Intel",
    "tipus": "Core2 Duo T6600"
  },
  {
    "id": 39,
    "gyarto": "Intel",
    "tipus": "Core2 Duo T6670"
  },
  {
    "id": 40,
    "gyarto": "Intel",
    "tipus": "Core2 Duo T7300"
  },
  {
    "id": 41,
    "gyarto": "Intel",
    "tipus": "Core2 Duo T7500"
  },
  {
    "id": 42,
    "gyarto": "Intel",
    "tipus": "Core2 Duo T8300"
  },
  {
    "id": 43,
    "gyarto": "Intel",
    "tipus": "Core2 Duo T9300"
  },
  {
    "id": 44,
    "gyarto": "Intel",
    "tipus": "Core2 Duo T9400"
  },
  {
    "id": 45,
    "gyarto": "Intel",
    "tipus": "Core2 Solo SU3500 ULV"
  },
  {
    "id": 46,
    "gyarto": "Intel",
    "tipus": "Pentium Dual Core SU4100"
  },
  {
    "id": 48,
    "gyarto": "Intel",
    "tipus": "Pentium dual-core T4200"
  },
  {
    "id": 49,
    "gyarto": "Intel",
    "tipus": "Pentium dual-core T4300"
  },
  {
    "id": 51,
    "gyarto": "Intel",
    "tipus": "Celeron M ULV723"
  },
  {
    "id": 52,
    "gyarto": "VIA",
    "tipus": "Via Nano ULV 2250"
  },
  {
    "id": 53,
    "gyarto": "AMD",
    "tipus": "Athlon 64 X2 QL65"
  }
];
export const oprendszerek = [
  {
    "id": 1,
    "nev": "FreeDOS"
  },
  {
    "id": 2,
    "nev": "Linux"
  },
  {
    "id": 3,
    "nev": "Microsoft Vista Business"
  },
  {
    "id": 4,
    "nev": "Microsoft Vista Home Basic HU"
  },
  {
    "id": 5,
    "nev": "Microsoft Vista Home Premium"
  },
  {
    "id": 6,
    "nev": "Microsoft Vista Home Premium HU"
  },
  {
    "id": 7,
    "nev": "Microsoft Vista Home Premium HU notebook"
  },
  {
    "id": 8,
    "nev": "nincs"
  },
  {
    "id": 9,
    "nev": "Windows 7 Home Premium HU 32Bit"
  },
  {
    "id": 10,
    "nev": "Windows 7 Home Premium HU 64Bit"
  },
  {
    "id": 11,
    "nev": "Windows 7 Starter Edition HU"
  },
  {
    "id": 12,
    "nev": "Windows XP Home Magyar"
  }
];
