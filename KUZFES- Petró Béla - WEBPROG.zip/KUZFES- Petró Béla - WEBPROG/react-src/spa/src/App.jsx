import { useMemo, useState } from 'react';
import { notebooks } from './data';

function PriceCalculator() {
  const [memoria, setMemoria] = useState(8);
  const [hattertar, setHattertar] = useState(256);
  const [windows, setWindows] = useState(true);
  const [gamerGpu, setGamerGpu] = useState(false);

  const price = useMemo(() => {
    let base = 120000;
    base += memoria * 12000;
    base += hattertar * 120;
    if (windows) base += 35000;
    if (gamerGpu) base += 90000;
    return base;
  }, [memoria, hattertar, windows, gamerGpu]);

  return (
    <div className="react-card">
      <h2>Notebook árkalkulátor</h2>
      <div className="form-grid">
        <div>
          <label>Memória (GB)</label>
          <input type="number" min="4" step="4" value={memoria} onChange={e => setMemoria(Number(e.target.value))} />
        </div>
        <div>
          <label>Háttértár (GB)</label>
          <input type="number" min="128" step="128" value={hattertar} onChange={e => setHattertar(Number(e.target.value))} />
        </div>
        <label><input type="checkbox" checked={windows} onChange={e => setWindows(e.target.checked)} /> Windows operációs rendszer</label>
        <label><input type="checkbox" checked={gamerGpu} onChange={e => setGamerGpu(e.target.checked)} /> Gamer videókártya</label>
      </div>
      <p className="small-muted">A számítás becslés, bemutató célra készült.</p>
      <div className="price">{new Intl.NumberFormat('hu-HU').format(price)} Ft</div>
    </div>
  );
}

function GuessThePrice() {
  const [index, setIndex] = useState(0);
  const [guess, setGuess] = useState('');
  const [message, setMessage] = useState('Adj meg egy árat, majd kattints az ellenőrzésre.');

  const item = notebooks[index % notebooks.length];
  function checkGuess() {
    const num = Number(guess);
    if (!num) {
      setMessage('Adj meg egy érvényes árat.');
      return;
    }
    const diff = Math.abs(item.ar - num);
    if (diff === 0) setMessage('Tökéletes találat!');
    else if (diff < 10000) setMessage('Nagyon közel voltál.');
    else if (num < item.ar) setMessage('Túl alacsony tipp.');
    else setMessage('Túl magas tipp.');
  }

  return (
    <div className="react-card">
      <h2>Találd ki a notebook árát</h2>
      <p><strong>{item.gyarto} {item.tipus}</strong></p>
      <p>Kijelző: {item.kijelzo}" | Memória: {item.memoria} MB | Processzor: {item.processzorNev}</p>
      <div className="controls">
        <input type="number" min="0" value={guess} onChange={e => setGuess(e.target.value)} placeholder="Tippelt ár (Ft)" />
        <button className="react-btn" onClick={checkGuess}>Ellenőrzés</button>
        <button className="react-btn secondary" onClick={() => { setIndex(prev => prev + 1); setGuess(''); setMessage('Új notebook betöltve.'); }}>Következő</button>
      </div>
      <div className="guess-result">{message}</div>
      <p className="small-muted">Valódi ár: {new Intl.NumberFormat('hu-HU').format(item.ar)} Ft</p>
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState('calc');
  return (
    <div className="react-shell">
      <div className="react-card">
        <h2>SPA alkalmazás</h2>
        <div className="tab-bar">
          <button className="react-btn" onClick={() => setTab('calc')}>Árkalkulátor</button>
          <button className="react-btn secondary" onClick={() => setTab('game')}>Árkitaláló játék</button>
        </div>
      </div>
      {tab === 'calc' ? <PriceCalculator /> : <GuessThePrice />}
    </div>
  );
}