# Web-programozás 1 – Notebook projekt

Ez a projekt a **Notebook** adatbázisra épülő beadandó mintamegoldás.

## Tartalom
- `index.html` – főoldal
- `javascript.html` – JavaScript CRUD helyi tömbből
- `react.html` – React CRUD
- `spa.html` – két menüpontos SPA
- `fetchapi.html` – Fetch API + PHP + MySQL CRUD
- `axios.html` – React + Axios + PHP + MySQL CRUD
- `oojs.html` – objektumorientált JavaScript grafikus alkalmazás
- `database/notebook.sql` – importálandó adatbázis
- `api/` – PHP backend
- `react-src/` – React források
- `react-dist/` – buildelt React fájlok

## Beállítás
1. Importáld a `database/notebook.sql` fájlt a tárhely adatbázisába.
2. Szerkeszd az `api/db.php` fájlban az adatbázis hozzáférést.
3. Töltsd fel a projektet a tárhelyre.
4. Nyisd meg az `index.html` oldalt.

## React forrás buildelése
A React oldalak buildelt állapota már benne van a projektben, de ha újra szeretnéd buildelni:

```bash
npm install
npm run build:all
```

## Csoportmunka javasolt felosztás
- **1. hallgató**: index, javascript, oojs, dizájn
- **2. hallgató**: react, spa, fetchapi, axios, php backend
- **Közös**: tesztelés, tárhely, dokumentáció, GitHub

## Fontos
A láblécben és a dokumentációban cseréljétek ki a helykitöltő adatokat a valódi nevekre, Neptun-kódokra, URL-ekre és tárhelyadatokra.
