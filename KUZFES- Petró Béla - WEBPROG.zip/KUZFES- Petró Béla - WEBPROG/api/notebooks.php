<?php
require_once __DIR__ . '/db.php';

function readJsonInput() {
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function response($data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function listNotebooks(PDO $dbh): array {
    $sql = "SELECT
                g.id,
                g.gyarto,
                g.tipus,
                g.kijelzo,
                g.memoria,
                g.merevlemez,
                g.videovezerlo,
                g.ar,
                g.processzorid,
                g.oprendszerid,
                g.db,
                CONCAT(p.gyarto, ' ', p.tipus) AS processzorNev,
                o.nev AS oprendszerNev
            FROM gep g
            INNER JOIN processzor p ON g.processzorid = p.id
            INNER JOIN oprendszer o ON g.oprendszerid = o.id
            ORDER BY g.id DESC";
    return $dbh->query($sql)->fetchAll();
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'GET') {
    response(['notebooks' => listNotebooks($dbh)]);
}

if ($method !== 'POST') {
    response(['error' => 'Nem támogatott kérés.'], 405);
}

$data = readJsonInput();
$action = $data['action'] ?? '';

$requiredFields = ['gyarto', 'tipus', 'kijelzo', 'memoria', 'merevlemez', 'videovezerlo', 'ar', 'processzorid', 'oprendszerid', 'db'];

if ($action === 'create' || $action === 'update') {
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || $data[$field] === '') {
            response(['error' => "Hiányzó mező: {$field}"], 422);
        }
    }
}

try {
    if ($action === 'create') {
        $stmt = $dbh->prepare(
            'INSERT INTO gep (gyarto, tipus, kijelzo, memoria, merevlemez, videovezerlo, ar, processzorid, oprendszerid, db)
             VALUES (:gyarto, :tipus, :kijelzo, :memoria, :merevlemez, :videovezerlo, :ar, :processzorid, :oprendszerid, :db)'
        );
        $stmt->execute([
            ':gyarto' => $data['gyarto'],
            ':tipus' => $data['tipus'],
            ':kijelzo' => $data['kijelzo'],
            ':memoria' => (int)$data['memoria'],
            ':merevlemez' => (int)$data['merevlemez'],
            ':videovezerlo' => $data['videovezerlo'],
            ':ar' => (int)$data['ar'],
            ':processzorid' => (int)$data['processzorid'],
            ':oprendszerid' => (int)$data['oprendszerid'],
            ':db' => (int)$data['db'],
        ]);
        response(['success' => true, 'message' => 'Notebook sikeresen létrehozva.']);
    }

    if ($action === 'update') {
        if (empty($data['id'])) {
            response(['error' => 'Hiányzó rekordazonosító.'], 422);
        }
        $stmt = $dbh->prepare(
            'UPDATE gep
             SET gyarto = :gyarto,
                 tipus = :tipus,
                 kijelzo = :kijelzo,
                 memoria = :memoria,
                 merevlemez = :merevlemez,
                 videovezerlo = :videovezerlo,
                 ar = :ar,
                 processzorid = :processzorid,
                 oprendszerid = :oprendszerid,
                 db = :db
             WHERE id = :id'
        );
        $stmt->execute([
            ':id' => (int)$data['id'],
            ':gyarto' => $data['gyarto'],
            ':tipus' => $data['tipus'],
            ':kijelzo' => $data['kijelzo'],
            ':memoria' => (int)$data['memoria'],
            ':merevlemez' => (int)$data['merevlemez'],
            ':videovezerlo' => $data['videovezerlo'],
            ':ar' => (int)$data['ar'],
            ':processzorid' => (int)$data['processzorid'],
            ':oprendszerid' => (int)$data['oprendszerid'],
            ':db' => (int)$data['db'],
        ]);
        response(['success' => true, 'message' => 'Notebook sikeresen módosítva.']);
    }

    if ($action === 'delete') {
        if (empty($data['id'])) {
            response(['error' => 'Hiányzó rekordazonosító.'], 422);
        }
        $stmt = $dbh->prepare('DELETE FROM gep WHERE id = :id');
        $stmt->execute([':id' => (int)$data['id']]);
        response(['success' => true, 'message' => 'Notebook sikeresen törölve.']);
    }

    response(['error' => 'Ismeretlen művelet.'], 400);
} catch (PDOException $e) {
    response(['error' => 'Adatbázis műveleti hiba: ' . $e->getMessage()], 500);
}
