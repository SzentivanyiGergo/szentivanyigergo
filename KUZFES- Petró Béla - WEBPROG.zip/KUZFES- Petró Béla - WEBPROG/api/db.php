<?php
header('Content-Type: application/json; charset=utf-8');

$host = 'localhost';
$dbname = 'adatb';
$username = 'adatbf';
$password = '****';

try {
    $dbh = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Adatbázis kapcsolódási hiba: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;
}
