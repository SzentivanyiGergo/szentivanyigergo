<?php
require_once __DIR__ . '/db.php';

$processzorok = $dbh->query('SELECT id, gyarto, tipus FROM processzor ORDER BY gyarto, tipus')->fetchAll();
$oprendszerek = $dbh->query('SELECT id, nev FROM oprendszer ORDER BY nev')->fetchAll();

echo json_encode([
    'processzorok' => $processzorok,
    'oprendszerek' => $oprendszerek
], JSON_UNESCAPED_UNICODE);
