class Notebook {
  constructor(gyarto, tipus, memoria, ar) {
    this.gyarto = gyarto;
    this.tipus = tipus;
    this.memoria = memoria;
    this.ar = ar;
  }
  getTitle() {
    return `${this.gyarto} ${this.tipus}`;
  }
  render() {
    const card = document.createElement('div');
    card.className = 'card info-card';
    card.innerHTML = `
      <span class="badge">Notebook</span>
      <h3>${this.getTitle()}</h3>
      <p><strong>Memória:</strong> ${this.memoria} MB</p>
      <p><strong>Ár:</strong> ${new Intl.NumberFormat('hu-HU').format(this.ar)} Ft</p>
    `;
    return card;
  }
}
class GamerNotebook extends Notebook {
  constructor(gyarto, tipus, memoria, ar, gpu) {
    super(gyarto, tipus, memoria, ar);
    this.gpu = gpu;
  }
  render() {
    const card = super.render();
    card.style.background = 'linear-gradient(180deg, rgba(17,24,39,.98), rgba(15,23,42,.92))';
    card.style.color = '#f8fafc';
    card.style.border = '1px solid rgba(239,68,68,.35)';
    card.innerHTML = `
      <span class="badge" style="background: rgba(239,68,68,.16); color: #fecaca;">Gamer notebook</span>
      <h3>${this.getTitle()}</h3>
      <p><strong>Memória:</strong> ${this.memoria} MB</p>
      <p><strong>Ár:</strong> ${new Intl.NumberFormat('hu-HU').format(this.ar)} Ft</p>
      <p><strong>GPU:</strong> ${this.gpu}</p>
    `;
    return card;
  }
}

const oojsArea = document.getElementById('oojsArea');
function appendCard(node) {
  document.body.appendChild(document.createComment('OOJS appendChild használat demonstráció'));
  oojsArea.appendChild(node);
}
document.getElementById('generateBaseBtn').addEventListener('click', () => {
  [
    new Notebook('Lenovo', 'ThinkPad T470', 8192, 169900),
    new Notebook('HP', 'EliteBook 840', 16384, 219900),
    new Notebook('Dell', 'Latitude 5490', 8192, 189900)
  ].forEach(item => appendCard(item.render()));
});
document.getElementById('generateGamerBtn').addEventListener('click', () => {
  [
    new GamerNotebook('ASUS', 'ROG Strix', 16384, 429900, 'NVIDIA RTX 4060'),
    new GamerNotebook('MSI', 'Katana', 16384, 389900, 'NVIDIA RTX 4050'),
    new GamerNotebook('Acer', 'Nitro 5', 16384, 349900, 'NVIDIA RTX 3050')
  ].forEach(item => appendCard(item.render()));
});
document.getElementById('clearOojsBtn').addEventListener('click', () => {
  oojsArea.innerHTML = '';
});