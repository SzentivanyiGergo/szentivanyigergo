const FORMATTER = new Intl.NumberFormat('hu-HU');
let notebooks = structuredClone(window.NOTEBOOK_DATA);
const lookup = window.LOOKUP_DATA;
let editingId = null;

const tableBody = document.getElementById('tableBody');
const searchInput = document.getElementById('searchInput');
const osFilter = document.getElementById('osFilter');
const sortSelect = document.getElementById('sortSelect');
const notebookForm = document.getElementById('notebookForm');
const processzorSelect = document.getElementById('processzorSelect');
const oprendszerSelect = document.getElementById('oprendszerSelect');
const recordInfo = document.getElementById('recordInfo');
const formTitle = document.getElementById('formTitle');
const cancelEditBtn = document.getElementById('cancelEditBtn');

function fillSelect(select, options, formatter) {
  select.innerHTML = options.map(option => `<option value="${option.id}">${formatter(option)}</option>`).join('');
}
function fillFilters() {
  osFilter.innerHTML = '<option value="">Minden operációs rendszer</option>' +
    lookup.oprendszerek.map(os => `<option value="${os.id}">${os.nev}</option>`).join('');
  fillSelect(processzorSelect, lookup.processzorok, p => `${p.gyarto} ${p.tipus}`);
  fillSelect(oprendszerSelect, lookup.oprendszerek, os => os.nev);
}
function getFilteredData() {
  const term = searchInput.value.trim().toLowerCase();
  const selectedOs = osFilter.value;
  const sorted = notebooks
    .filter(item => {
      const haystack = `${item.gyarto} ${item.tipus} ${item.videovezerlo}`.toLowerCase();
      const osMatch = !selectedOs || String(item.oprendszerid) === selectedOs;
      return haystack.includes(term) && osMatch;
    })
    .sort((a, b) => {
      switch (sortSelect.value) {
        case 'ar-desc': return b.ar - a.ar;
        case 'memoria-desc': return b.memoria - a.memoria;
        case 'merevlemez-desc': return b.merevlemez - a.merevlemez;
        case 'gyarto-asc': return a.gyarto.localeCompare(b.gyarto, 'hu');
        default: return a.ar - b.ar;
      }
    });
  return sorted;
}
function renderTable() {
  const filtered = getFilteredData();
  recordInfo.textContent = `${filtered.length} darab rekord látható a ${notebooks.length} notebookból.`;
  if (!filtered.length) {
    tableBody.innerHTML = `<tr><td colspan="12" class="empty">Nincs a feltételeknek megfelelő rekord.</td></tr>`;
    return;
  }
  tableBody.innerHTML = filtered.map(item => `
    <tr>
      <td>${item.id}</td>
      <td><span class="pill">${item.gyarto}</span></td>
      <td>${item.tipus}</td>
      <td>${item.kijelzo}"</td>
      <td>${FORMATTER.format(item.memoria)} MB</td>
      <td>${FORMATTER.format(item.merevlemez)} GB</td>
      <td>${item.videovezerlo}</td>
      <td>${FORMATTER.format(item.ar)} Ft</td>
      <td>${item.processzorNev}</td>
      <td>${item.oprendszerNev}</td>
      <td>${item.db}</td>
      <td>
        <div class="action-row">
          <button class="mini-btn edit-btn" onclick="startEdit(${item.id})">Szerkesztés</button>
          <button class="mini-btn delete-btn" onclick="removeNotebook(${item.id})">Törlés</button>
        </div>
      </td>
    </tr>
  `).join('');
}
function resetForm() {
  notebookForm.reset();
  editingId = null;
  formTitle.textContent = 'Új notebook felvitele';
}
function getLookupNames(processzorid, oprendszerid) {
  const p = lookup.processzorok.find(item => item.id === Number(processzorid));
  const os = lookup.oprendszerek.find(item => item.id === Number(oprendszerid));
  return {
    processzorNev: p ? `${p.gyarto} ${p.tipus}` : '',
    oprendszerNev: os ? os.nev : ''
  };
}
window.startEdit = function(id) {
  const item = notebooks.find(entry => entry.id === id);
  if (!item) return;
  editingId = id;
  formTitle.textContent = `Notebook szerkesztése (#${id})`;
  Object.entries(item).forEach(([key, value]) => {
    const field = notebookForm.elements.namedItem(key);
    if (field) field.value = value;
  });
  notebookForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
};
window.removeNotebook = function(id) {
  if (!confirm('Biztosan törölni szeretnéd ezt a notebookot?')) return;
  notebooks = notebooks.filter(item => item.id !== id);
  renderTable();
  if (editingId === id) resetForm();
};
notebookForm.addEventListener('submit', event => {
  event.preventDefault();
  const formData = new FormData(notebookForm);
  const item = Object.fromEntries(formData.entries());
  ['memoria', 'merevlemez', 'ar', 'processzorid', 'oprendszerid', 'db'].forEach(key => item[key] = Number(item[key]));
  const names = getLookupNames(item.processzorid, item.oprendszerid);
  if (editingId) {
    notebooks = notebooks.map(entry => entry.id === editingId ? { ...entry, ...item, ...names, id: editingId } : entry);
  } else {
    const newId = Math.max(...notebooks.map(entry => entry.id), 0) + 1;
    notebooks.unshift({ ...item, ...names, id: newId });
  }
  resetForm();
  renderTable();
});
[searchInput, osFilter, sortSelect].forEach(element => element.addEventListener('input', renderTable));
document.getElementById('resetBtn').addEventListener('click', () => {
  searchInput.value = '';
  osFilter.value = '';
  sortSelect.value = 'ar-asc';
  renderTable();
});
cancelEditBtn.addEventListener('click', resetForm);

fillFilters();
renderTable();