const fmt = new Intl.NumberFormat('hu-HU');
const apiUrl = 'api/notebooks.php';
const lookupUrl = 'api/lookups.php';

let fetchState = {
  notebooks: [],
  filtered: [],
  processzorok: [],
  oprendszerek: [],
  editingId: null
};

const fetchStatus = document.getElementById('fetchStatus');
const fetchSearch = document.getElementById('fetchSearch');
const fetchTableBody = document.getElementById('fetchTableBody');
const fetchForm = document.getElementById('fetchNotebookForm');
const fetchFormTitle = document.getElementById('fetchFormTitle');
const fetchProcesszorSelect = document.getElementById('fetchProcesszorSelect');
const fetchOprendszerSelect = document.getElementById('fetchOprendszerSelect');

function setStatus(message, isError = false) {
  fetchStatus.textContent = message;
  fetchStatus.style.color = isError ? '#b91c1c' : '';
}
async function fetchJson(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok || data.error) throw new Error(data.error || 'Ismeretlen szerverhiba.');
  return data;
}
function fillFetchSelects() {
  fetchProcesszorSelect.innerHTML = fetchState.processzorok.map(item => `<option value="${item.id}">${item.gyarto} ${item.tipus}</option>`).join('');
  fetchOprendszerSelect.innerHTML = fetchState.oprendszerek.map(item => `<option value="${item.id}">${item.nev}</option>`).join('');
}
function renderFetchTable() {
  const term = fetchSearch.value.trim().toLowerCase();
  fetchState.filtered = fetchState.notebooks.filter(item => {
    const haystack = `${item.gyarto} ${item.tipus} ${item.processzorNev} ${item.oprendszerNev}`.toLowerCase();
    return haystack.includes(term);
  });
  if (!fetchState.filtered.length) {
    fetchTableBody.innerHTML = `<tr><td colspan="11" class="empty">Nincs megjeleníthető adat.</td></tr>`;
    return;
  }
  fetchTableBody.innerHTML = fetchState.filtered.map(item => `
    <tr>
      <td>${item.id}</td>
      <td><span class="pill">${item.gyarto}</span></td>
      <td>${item.tipus}</td>
      <td>${item.kijelzo}"</td>
      <td>${fmt.format(item.memoria)} MB</td>
      <td>${fmt.format(item.merevlemez)} GB</td>
      <td>${fmt.format(item.ar)} Ft</td>
      <td>${item.processzorNev}</td>
      <td>${item.oprendszerNev}</td>
      <td>${item.db}</td>
      <td>
        <div class="action-row">
          <button class="mini-btn edit-btn" onclick="startFetchEdit(${item.id})">Szerkesztés</button>
          <button class="mini-btn delete-btn" onclick="deleteFetchNotebook(${item.id})">Törlés</button>
        </div>
      </td>
    </tr>
  `).join('');
}
async function loadFetchLookups() {
  const data = await fetchJson(lookupUrl);
  fetchState.processzorok = data.processzorok;
  fetchState.oprendszerek = data.oprendszerek;
  fillFetchSelects();
}
async function loadFetchNotebooks() {
  setStatus('Adatok betöltése...');
  const data = await fetchJson(apiUrl);
  fetchState.notebooks = data.notebooks;
  renderFetchTable();
  setStatus(`${fetchState.notebooks.length} rekord betöltve az adatbázisból.`);
}
window.startFetchEdit = function(id) {
  const item = fetchState.notebooks.find(entry => Number(entry.id) === id);
  if (!item) return;
  fetchState.editingId = id;
  fetchFormTitle.textContent = `Notebook szerkesztése (#${id})`;
  Object.entries(item).forEach(([key, value]) => {
    const field = fetchForm.elements.namedItem(key);
    if (field) field.value = value;
  });
};
window.deleteFetchNotebook = async function(id) {
  if (!confirm('Biztosan törölni szeretnéd ezt a rekordot?')) return;
  try {
    await fetchJson(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'delete', id })
    });
    await loadFetchNotebooks();
  } catch (error) {
    setStatus(error.message, true);
  }
};
function resetFetchForm() {
  fetchForm.reset();
  fetchState.editingId = null;
  fetchFormTitle.textContent = 'Új notebook rögzítése';
}
fetchForm.addEventListener('submit', async event => {
  event.preventDefault();
  const formData = Object.fromEntries(new FormData(fetchForm).entries());
  const payload = {
    action: fetchState.editingId ? 'update' : 'create',
    ...formData,
    id: fetchState.editingId
  };
  try {
    await fetchJson(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    resetFetchForm();
    await loadFetchNotebooks();
  } catch (error) {
    setStatus(error.message, true);
  }
});
document.getElementById('fetchReloadBtn').addEventListener('click', loadFetchNotebooks);
document.getElementById('fetchCancelEditBtn').addEventListener('click', resetFetchForm);
fetchSearch.addEventListener('input', renderFetchTable);

(async function initFetchPage() {
  try {
    await loadFetchLookups();
    await loadFetchNotebooks();
  } catch (error) {
    setStatus(`Hiba: ${error.message}`, true);
  }
})();