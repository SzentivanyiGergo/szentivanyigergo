import { useEffect, useMemo, useState } from 'react';
import axios from 'axios';

const api = 'api/notebooks.php';
const lookupsApi = 'api/lookups.php';
const formatter = new Intl.NumberFormat('hu-HU');

export default function App() {
  const [items, setItems] = useState([]);
  const [processzorok, setProcesszorok] = useState([]);
  const [oprendszerek, setOprendszerek] = useState([]);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('Adatok betöltése...');
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState({
    gyarto: '',
    tipus: '',
    kijelzo: '',
    memoria: '',
    merevlemez: '',
    videovezerlo: '',
    ar: '',
    processzorid: '',
    oprendszerid: '',
    db: 0
  });

  useEffect(() => {
    loadLookups();
    loadItems();
  }, []);

  async function loadLookups() {
    const { data } = await axios.get(lookupsApi);
    setProcesszorok(data.processzorok);
    setOprendszerek(data.oprendszerek);
    setForm(prev => ({
      ...prev,
      processzorid: data.processzorok[0]?.id || '',
      oprendszerid: data.oprendszerek[0]?.id || ''
    }));
  }

  async function loadItems() {
    try {
      const { data } = await axios.get(api);
      setItems(data.notebooks);
      setStatus(`${data.notebooks.length} rekord betöltve.`);
    } catch (error) {
      setStatus(error.response?.data?.error || error.message);
    }
  }

  const filtered = useMemo(() => {
    return items.filter(item => {
      const haystack = `${item.gyarto} ${item.tipus} ${item.processzorNev}`.toLowerCase();
      return haystack.includes(search.toLowerCase());
    });
  }, [items, search]);

  function updateField(event) {
    const { name, value } = event.target;
    setForm(prev => ({ ...prev, [name]: value }));
  }

  function startEdit(item) {
    setEditingId(item.id);
    setForm({
      gyarto: item.gyarto,
      tipus: item.tipus,
      kijelzo: item.kijelzo,
      memoria: item.memoria,
      merevlemez: item.merevlemez,
      videovezerlo: item.videovezerlo,
      ar: item.ar,
      processzorid: item.processzorid,
      oprendszerid: item.oprendszerid,
      db: item.db
    });
  }

  function resetForm() {
    setEditingId(null);
    setForm({
      gyarto: '',
      tipus: '',
      kijelzo: '',
      memoria: '',
      merevlemez: '',
      videovezerlo: '',
      ar: '',
      processzorid: processzorok[0]?.id || '',
      oprendszerid: oprendszerek[0]?.id || '',
      db: 0
    });
  }

  async function submit(event) {
    event.preventDefault();
    try {
      await axios.post(api, {
        action: editingId ? 'update' : 'create',
        id: editingId,
        ...form
      });
      resetForm();
      loadItems();
    } catch (error) {
      setStatus(error.response?.data?.error || error.message);
    }
  }

  async function removeItem(id) {
    if (!window.confirm('Biztosan törlöd a rekordot?')) return;
    await axios.post(api, { action: 'delete', id });
    loadItems();
  }

  return (
    <div className="react-shell">
      <div className="react-card">
        <h2>Axios + React CRUD</h2>
        <div className="controls">
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Keresés..." />
          <div className="count-pill">{filtered.length} rekord</div>
          <div className="small-muted">{status}</div>
        </div>
      </div>

      <div className="react-card">
        <h2>{editingId ? `Szerkesztés (#${editingId})` : 'Új notebook rögzítése'}</h2>
        <form onSubmit={submit}>
          <div className="form-grid">
            <input name="gyarto" value={form.gyarto} onChange={updateField} placeholder="Gyártó" required />
            <input name="tipus" value={form.tipus} onChange={updateField} placeholder="Típus" required />
            <input name="kijelzo" value={form.kijelzo} onChange={updateField} placeholder="Kijelző" required />
            <input name="memoria" type="number" value={form.memoria} onChange={updateField} placeholder="Memória" required />
            <input name="merevlemez" type="number" value={form.merevlemez} onChange={updateField} placeholder="Háttértár" required />
            <input name="videovezerlo" value={form.videovezerlo} onChange={updateField} placeholder="Videovezérlő" required />
            <input name="ar" type="number" value={form.ar} onChange={updateField} placeholder="Ár" required />
            <select name="processzorid" value={form.processzorid} onChange={updateField}>
              {processzorok.map(item => <option key={item.id} value={item.id}>{item.gyarto} {item.tipus}</option>)}
            </select>
            <select name="oprendszerid" value={form.oprendszerid} onChange={updateField}>
              {oprendszerek.map(item => <option key={item.id} value={item.id}>{item.nev}</option>)}
            </select>
            <input name="db" type="number" value={form.db} onChange={updateField} placeholder="Darabszám" required />
          </div>
          <div className="react-actions" style={{ marginTop: 12 }}>
            <button className="react-btn" type="submit">Mentés</button>
            <button className="react-btn secondary" type="button" onClick={resetForm}>Mégse</button>
          </div>
        </form>
      </div>

      <div className="react-card">
        <h2>Adatbázisból töltött rekordok</h2>
        <div className="react-table-wrap">
          <table className="react-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Gyártó</th>
                <th>Típus</th>
                <th>Ár</th>
                <th>Processzor</th>
                <th>Operációs rendszer</th>
                <th>Művelet</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(item => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.gyarto}</td>
                  <td>{item.tipus}</td>
                  <td>{formatter.format(item.ar)} Ft</td>
                  <td>{item.processzorNev}</td>
                  <td>{item.oprendszerNev}</td>
                  <td>
                    <div className="react-actions">
                      <button className="react-btn secondary" onClick={() => startEdit(item)}>Szerkesztés</button>
                      <button className="react-btn danger" onClick={() => removeItem(item.id)}>Törlés</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}