# Dokumentációs vázlat

## 1. Címlap
- Projekt neve
- Készítők: Szentiványi Gergő (CDHZHK) és Petró Béla (KUZFES)

## 2. A projekt célja
- Miért ezt az adatbázist választottátok
- Rövid alkalmazásbemutatás

## 3. Választott adatbázis bemutatása
- `gep`
- `processzor`
- `oprendszer`

## 4. Főoldal menü
- képernyőkép
- melyik követelmény hol valósul meg

## 5. JavaScript menü
- CRUD leírása
- képernyőkép

## 6. React menü
- komponensek
- useState használat
- képernyőkép

## 7. SPA menü
- 1. alkalmazás: árkalkulátor
- 2. alkalmazás: árkitaláló játék
- képernyőképek
- forrásmegjelölés: saját megoldás / felhasznált inspiráció

## 8. Fetch API menü
- kliens-szerver kommunikáció
- képernyőkép

## 9. Axios menü
- React + Axios működése
- képernyőkép

## 10. OOJS menü
- class, constructor, extends, super, appendChild használata
- képernyőkép

## 11. Tárhely
- weboldal URL
- FTP adatok
- adatbázis elérés

## 12. GitHub
- repo URL
- legalább 5 commit
- ki melyik részt készítette

## 13. Összegzés
- nehézségek
- tanulságok
